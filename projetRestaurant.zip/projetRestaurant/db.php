<?php
session_start();

$conn = mysqli_connect(
  'localhost',
  'root',
  '',
  'nfa021',
  3308

) or die(mysqli_erro($mysqli));

?>
